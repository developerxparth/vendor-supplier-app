def get_location():
 return 'Patna, Bihar'